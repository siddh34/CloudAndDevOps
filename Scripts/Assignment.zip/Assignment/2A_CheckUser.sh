if [ `whoami` != root ]; then
    echo "you are not a root user!"
    exit
fi