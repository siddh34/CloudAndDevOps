# Suppose installing the mysql shell in linux 

echo "`sudo apt-get update`"
echo "`sudo apt-get install mysql-shell`"